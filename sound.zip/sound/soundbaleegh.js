let col1 = document.getElementById('column1')
let col2 = document.getElementById('column2')
let col3 = document.getElementById('column3')

col1.onmouseenter = () => {
	console.log('yes')
	col1.style.opacity= 1;
	
}

col1.onmouseleave = () => {
	console.log('yes')
	col1.style.opacity= 0.2;
	
}

col2.onmouseenter = () => {
	console.log('yes')
	col2.style.opacity= 1;
	
}

col2.onmouseleave = () => {
	console.log('yes')
	col2.style.opacity= 0.2;
	
}

col3.onmouseenter = () => {
	console.log('yes')
	col3.style.opacity= 1;
	
}

col3.onmouseleave = () => {
	console.log('yes')
	col3.style.opacity= 0.2;
	
}